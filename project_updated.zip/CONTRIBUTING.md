# Contribuindo

Obrigado por considerar contribuir para este projeto!

## Como Contribuir
1. Faça um fork do repositório.
2. Crie um branch para sua modificação (`git checkout -b feature/nova-feature`).
3. Faça commit de suas mudanças (`git commit -am 'Adiciona nova feature'`).
4. Faça push para o branch (`git push origin feature/nova-feature`).
5. Crie um novo Pull Request.