# Instalação

1. Baixe e instale o UnoArdoSim a partir do site oficial.
2. Carregue o código no UnoArdoSim.

## Configuração do Software
Conecte os pinos no UnoArdoSim conforme especificado no código (setup()).